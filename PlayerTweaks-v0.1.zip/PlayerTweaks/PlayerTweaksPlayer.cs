using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace PlayerTweaks
{
	public class PlayerTweaksPlayer : ModPlayer
	{
		public override void PostUpdateMiscEffects()
		{
			if (PlayerTweaksConfig.Instance.enablePlayerTweaks)
			{
				if (PlayerTweaksConfig.Instance.enablePlayerTweaksMovement)
				{
					Player.jumpHeight = PlayerTweaksConfig.Instance.playerJumpHeight;
					Player.jumpSpeed = PlayerTweaksConfig.Instance.playerJumpSpeed;
					Player.gravity = PlayerTweaksConfig.Instance.playerGravity;
				}
				if (PlayerTweaksConfig.Instance.enablePlayerTweaksLife)
				{
					Player.lifeRegen = PlayerTweaksConfig.Instance.playerLifeRegen;
					//Player.statLifeMax2 *=  (int)(Player.statLifeMax * PlayerTweaksConfig.Instance.playerLifeMax);
					//Disabled until I figure out how to fix it.
				}
			}
		}
		public override void PostUpdateRunSpeeds()
		{
			if (PlayerTweaksConfig.Instance.enablePlayerTweaks)
			{
				if (PlayerTweaksConfig.Instance.enablePlayerTweaksMovement)
				{
					Player.maxRunSpeed = PlayerTweaksConfig.Instance.playerRunSpeedMax;
					Player.runAcceleration = PlayerTweaksConfig.Instance.playerRunAcceleration;
					Player.runSlowdown = PlayerTweaksConfig.Instance.playerRunSlowdown;
				}
			}
		}
	}
}