using System.ComponentModel;
using Terraria.ModLoader.Config;

namespace PlayerTweaks
{
    [Label("Server Config")]
    public class PlayerTweaksConfig : ModConfig
    {
        //This is here for the Config to work at all.
        public override ConfigScope Mode => ConfigScope.ServerSide;
		
        public static PlayerTweaksConfig Instance;
		
        [Label("Enable Mod")]
        [Tooltip("If false, this mod's features are disabled.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enablePlayerTweaks {get; set;}
		
        [Header("Player Movement")]
		
        [Label("Enable This Section")]
        [Tooltip("If false, Player Movement modifiers will not be applied.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enablePlayerTweaksMovement {get; set;}
		
        [Label("Jump Height")]
        [Tooltip("How high Players will jump.\n[Default: 15]")]
        [Slider]
        [DefaultValue(15)]
        [Range(1, 30)]
        [Increment(1)]
        public int playerJumpHeight {get; set;}
		
        [Label("Jump Speed")]
        [Tooltip("How quickly Players will jump.\n[Default: 5.01]")]
        [Slider]
        [DefaultValue(5.01f)]
        [Range(1f, 10f)]
        [Increment(1f)]
        public float playerJumpSpeed {get; set;}
		
        [Label("Gravity")]
        [Tooltip("How strong Gravity is for Players.\n[Default: 0.4]")]
        [Slider]
        [DefaultValue(0.4f)]
        [Range(0.1f, 1f)]
        [Increment(0.1f)]
        public float playerGravity {get; set;}
		
        [Label("Max Run Speed")]
        [Tooltip("The maximum Run Speed for Players.\n[Default: 3]")]
        [Slider]
        [DefaultValue(3f)]
        [Range(1f, 10f)]
        [Increment(1f)]
        public float playerRunSpeedMax {get; set;}
		
        [Label("Run Acceleration")]
        [Tooltip("How quickly Players reach max speed when running.\n[Default: 0.08]")]
        [Slider]
        [DefaultValue(0.08f)]
        [Range(0.05f, 1f)]
        [Increment(0.05f)]
        public float playerRunAcceleration {get; set;}
		
        [Label("Run Slowdown")]
        [Tooltip("How quickly Players slow down when running.\n[Default: 0.2]")]
        [Slider]
        [DefaultValue(0.2f)]
        [Range(0.1f, 1f)]
        [Increment(0.1f)]
        public float playerRunSlowdown {get; set;}
		
        [Header("Player Life")]
		
        [Label("Enable This Section")]
        [Tooltip("If false, Player Life modifiers will not be applied.\n[Default: On]")]
        [DefaultValue(true)]
        public bool enablePlayerTweaksLife {get; set;}
		
        [Label("Life Regeneration")]
        [Tooltip("How fast Players regenerate Life.\n[Default: 3]")]
        [Slider]
        [DefaultValue(3)]
        [Range(0, 10)]
        [Increment(1)]
        public int playerLifeRegen {get; set;}
		
        /*[Label("Max Life")]
        [Tooltip("Max Life Multiplier for Players.\n(Doesn't work right now.)\n[Default: 1f]")]
        [Slider]
        [DefaultValue(1f)]
        [Range(0.25f, 4f)]
        [Increment(0.05f)]
        public float playerLifeMax {get; set;}*/
    }
}